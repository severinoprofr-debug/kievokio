'use client'

import { useState } from 'react'
import { notFound, useRouter } from 'next/navigation'
import Link from 'next/link'
import Header from '../../components/Header'
import BottomNav from '../../components/BottomNav'
import ProductCard from '../../components/ProductCard'
import { getById, products } from '../../data/products'
import { useCartStore } from '../../store/cart'
import { useUserStore } from '../../store/user'

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = getById(params.id)
  if (!product) notFound()

  const [selectedSize, setSelectedSize] = useState('')
  const [selectedColor, setSelectedColor] = useState(product.colors[0])
  const [selectedColorHex, setSelectedColorHex] = useState(product.colorHex[0])
  const [imgIdx, setImgIdx] = useState(0)
  const [added, setAdded] = useState(false)
  const [sizeError, setSizeError] = useState(false)

  const addItem = useCartStore(s => s.addItem)
  const wishlist = useUserStore(s => s.wishlist)
  const toggleWishlist = useUserStore(s => s.toggleWishlist)
  const isWished = wishlist.includes(product.id)
  const router = useRouter()

  const allImages = product.images.length > 0 ? product.images : [product.image]

  const handleAddToCart = () => {
    if (!selectedSize) { setSizeError(true); return }
    setSizeError(false)
    addItem(product, selectedSize, selectedColor, selectedColorHex)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  const related = products.filter(p => p.categorySlug === product.categorySlug && p.id !== product.id).slice(0, 4)
  const discount = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : null

  return (
    <div>
      {/* Transparent header over image */}
      <header className="fixed top-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] z-40 h-[60px] flex items-center justify-between px-4">
        <button onClick={() => router.back()}
          className="w-10 h-10 rounded-full bg-bg/60 backdrop-blur-md flex items-center justify-center press-effect text-offwhite">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M19 12H5M12 5l-7 7 7 7" />
          </svg>
        </button>
        <button onClick={() => toggleWishlist(product.id)}
          className={`w-10 h-10 rounded-full backdrop-blur-md flex items-center justify-center press-effect
            ${isWished ? 'bg-gold text-bg' : 'bg-bg/60 text-offwhite'}`}>
          <svg width="18" height="18" viewBox="0 0 24 24"
            fill={isWished ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2">
            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" />
          </svg>
        </button>
      </header>

      <div className="overflow-y-auto h-[100dvh] pb-32" style={{ scrollbarWidth: 'none' }}>
        {/* Images */}
        <div className="relative aspect-[3/4] bg-s2">
          <img src={allImages[imgIdx] || product.image} alt={product.name}
            className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-bg/60 to-transparent" />

          {/* Thumbnail dots */}
          {allImages.length > 1 && (
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5">
              {allImages.map((_, i) => (
                <button key={i} onClick={() => setImgIdx(i)}
                  className={`rounded-full transition-all ${i === imgIdx ? 'w-4 h-1.5 bg-gold' : 'w-1.5 h-1.5 bg-offwhite/40'}`} />
              ))}
            </div>
          )}

          {/* Sale badge */}
          {discount && (
            <div className="absolute top-16 left-4 bg-danger text-offwhite text-xs font-body font-semibold px-3 py-1 rounded">
              -{discount}%
            </div>
          )}
        </div>

        {/* Details */}
        <div className="px-4 pt-4">
          {/* Header */}
          <div className="flex items-start justify-between mb-1">
            <div className="flex-1">
              <p className="font-body text-[11px] text-muted uppercase tracking-wider mb-1">{product.category}</p>
              <h1 className="font-display text-2xl text-offwhite font-medium leading-tight">{product.name}</h1>
            </div>
          </div>

          {/* Price + rating */}
          <div className="flex items-center justify-between mt-2 mb-4">
            <div className="flex items-center gap-2">
              <span className="font-body text-xl font-semibold text-gold">{product.price}€</span>
              {product.originalPrice && (
                <span className="font-body text-sm text-muted line-through">{product.originalPrice}€</span>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="#BFA46E" stroke="#BFA46E" strokeWidth="1">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
              <span className="font-body text-xs text-offwhite">{product.rating}</span>
              <span className="font-body text-xs text-muted">({product.reviews})</span>
            </div>
          </div>

          {/* Loyalty points */}
          <div className="flex items-center gap-2 p-3 rounded-xl bg-gold/5 border border-gold/15 mb-4">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#BFA46E" strokeWidth="1.8">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            <p className="font-body text-xs text-gold">Gagnez <strong>+{product.loyaltyPoints} points</strong> pour cet achat</p>
          </div>

          {/* Colors */}
          <div className="mb-4">
            <p className="font-body text-xs text-muted mb-2">Couleur · <span className="text-offwhite">{selectedColor}</span></p>
            <div className="flex gap-2">
              {product.colors.map((color, i) => (
                <button key={color}
                  onClick={() => { setSelectedColor(color); setSelectedColorHex(product.colorHex[i]) }}
                  className={`relative w-8 h-8 rounded-full border-2 transition-all press-effect
                    ${selectedColor === color ? 'border-gold' : 'border-border'}`}
                  style={{ backgroundColor: product.colorHex[i] }}
                  title={color}>
                  {selectedColor === color && (
                    <span className="absolute inset-0 flex items-center justify-center">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={
                        product.colorHex[i] === '#FAFAF8' || product.colorHex[i] === '#F5F0E8' ? '#111' : '#fff'
                      } strokeWidth="3">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Sizes */}
          <div className="mb-5">
            <div className="flex items-center justify-between mb-2">
              <p className={`font-body text-xs ${sizeError ? 'text-danger' : 'text-muted'}`}>
                {sizeError ? '⚠ Sélectionnez une taille' : 'Taille'}
                {selectedSize && <span className="text-offwhite"> · {selectedSize}</span>}
              </p>
              <button className="font-body text-xs text-gold">Guide des tailles</button>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map(size => (
                <button key={size}
                  onClick={() => { setSelectedSize(size); setSizeError(false) }}
                  className={`font-body text-xs font-medium px-4 py-2 rounded-lg border transition-all press-effect
                    ${selectedSize === size
                      ? 'bg-gold text-bg border-gold'
                      : 'bg-transparent text-offwhite border-border'}`}>
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="mb-4">
            <p className="font-body text-sm text-muted leading-relaxed">{product.description}</p>
          </div>

          {/* Details */}
          <div className="mb-6">
            <p className="font-body text-xs font-medium text-offwhite mb-2 uppercase tracking-wider">Composition & Soin</p>
            <ul className="space-y-1">
              {product.details.map(d => (
                <li key={d} className="font-body text-xs text-muted flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-gold/50 flex-shrink-0" />
                  {d}
                </li>
              ))}
            </ul>
          </div>

          {/* Livraison */}
          <div className="grid grid-cols-3 gap-2 mb-6">
            {[
              { icon: '🚚', label: 'Livraison', sub: 'Gratuite > 100€' },
              { icon: '↩️', label: 'Retour', sub: '30 jours' },
              { icon: '🔒', label: 'Paiement', sub: '100% sécurisé' },
            ].map(item => (
              <div key={item.label} className="flex flex-col items-center text-center p-3 rounded-xl bg-s2">
                <span className="text-lg mb-1">{item.icon}</span>
                <p className="font-body text-[10px] font-medium text-offwhite">{item.label}</p>
                <p className="font-body text-[10px] text-muted">{item.sub}</p>
              </div>
            ))}
          </div>

          {/* Related */}
          {related.length > 0 && (
            <div className="mb-4">
              <h2 className="font-display text-xl text-offwhite mb-3">Vous aimerez aussi</h2>
              <div className="scroll-x flex gap-3 pb-1">
                {related.map(p => (
                  <div key={p.id} className="flex-shrink-0 w-[150px]">
                    <ProductCard product={p} size="sm" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add to cart CTA */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] px-4 pb-6 pt-3 bg-bg/95 backdrop-blur-md border-t border-border/50 z-50"
        style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 16px)' }}>
        <button onClick={handleAddToCart}
          className={`w-full py-4 rounded-2xl font-body font-semibold text-sm transition-all press-effect
            ${added
              ? 'bg-green-600 text-offwhite'
              : 'bg-gold text-bg'}`}>
          {added ? '✓ Ajouté au panier' : `Ajouter au panier — ${product.price}€`}
        </button>
      </div>
    </div>
  )
}
