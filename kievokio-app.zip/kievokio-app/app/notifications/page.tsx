'use client'

import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import { useUserStore } from '../store/user'

const NOTIF_ICONS: Record<string, string> = {
  order: '📦',
  promo: '🏷️',
  loyalty: '⭐',
  new: '✨',
}

const NOTIF_COLORS: Record<string, string> = {
  order: 'border-blue-500/20 bg-blue-500/5',
  promo: 'border-danger/20 bg-danger/5',
  loyalty: 'border-gold/20 bg-gold/5',
  new: 'border-s3 bg-s2',
}

export default function NotificationsPage() {
  const { notifications, markNotifRead, markAllNotifRead, unreadCount } = useUserStore()
  const unread = unreadCount()

  return (
    <div>
      <Header
        title="Notifications"
        showBack
        backHref="/"
        rightAction={
          unread > 0 ? (
            <button onClick={markAllNotifRead}
              className="font-body text-xs text-gold press-effect px-2">
              Tout lire
            </button>
          ) : undefined
        }
      />

      <div className="page-scroll">
        {/* Unread count */}
        {unread > 0 && (
          <div className="mx-4 mb-4 flex items-center gap-2 p-3 rounded-xl bg-gold/5 border border-gold/15">
            <span className="w-2 h-2 rounded-full bg-gold flex-shrink-0" />
            <p className="font-body text-xs text-gold">
              {unread} notification{unread > 1 ? 's' : ''} non lue{unread > 1 ? 's' : ''}
            </p>
          </div>
        )}

        {/* Notifications list */}
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-8">
            <span className="text-5xl mb-3">🔕</span>
            <p className="font-display text-xl text-offwhite mb-1">Aucune notification</p>
            <p className="font-body text-sm text-muted">Vous êtes à jour !</p>
          </div>
        ) : (
          <div className="px-4 space-y-2 mb-4">
            {notifications.map(notif => (
              <button
                key={notif.id}
                onClick={() => markNotifRead(notif.id)}
                className={`w-full text-left p-4 rounded-2xl border transition-all press-effect relative overflow-hidden
                  ${notif.read ? 'border-border bg-s2 opacity-70' : NOTIF_COLORS[notif.type]}`}>

                {/* Unread indicator */}
                {!notif.read && (
                  <span className="absolute top-3 right-3 w-2 h-2 rounded-full bg-gold" />
                )}

                <div className="flex gap-3 items-start">
                  <span className="text-xl flex-shrink-0 mt-0.5">{NOTIF_ICONS[notif.type]}</span>
                  <div className="flex-1 min-w-0 pr-3">
                    <p className={`font-body text-sm font-medium leading-snug mb-0.5
                      ${notif.read ? 'text-muted' : 'text-offwhite'}`}>
                      {notif.title}
                    </p>
                    <p className="font-body text-xs text-muted leading-relaxed">{notif.body}</p>
                    <p className="font-body text-[10px] text-muted/70 mt-1.5">{notif.date}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Push notifications opt-in */}
        <div className="mx-4 mt-4 p-4 rounded-2xl border border-gold/15 bg-gold/5 mb-4">
          <p className="font-body text-xs font-medium text-offwhite mb-1">🔔 Notifications push</p>
          <p className="font-body text-xs text-muted mb-3">
            Activez les notifications pour recevoir les offres exclusives et suivre vos commandes en temps réel.
          </p>
          <button className="w-full py-2.5 bg-gold text-bg rounded-xl font-body text-xs font-semibold press-effect">
            Activer les notifications
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
