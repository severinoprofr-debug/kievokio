'use client'

import { useState } from 'react'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import { useUserStore, getNextTier, getNextTierThreshold, getTierProgress, TIER_THRESHOLDS } from '../store/user'
import type { LoyaltyTier } from '../store/user'

const TIER_COLORS: Record<LoyaltyTier, { bg: string; text: string; border: string; glow: string }> = {
  Bronze: { bg: 'from-amber-900/40 to-amber-800/20', text: '#CD7F32', border: 'border-amber-700/30', glow: '' },
  Argent: { bg: 'from-slate-600/40 to-slate-500/20', text: '#A8A9AD', border: 'border-slate-500/30', glow: '' },
  Or: { bg: 'from-yellow-700/40 to-yellow-600/20', text: '#BFA46E', border: 'border-yellow-600/30', glow: 'tier-gold' },
  Platine: { bg: 'from-indigo-900/40 to-violet-800/20', text: '#BFA46E', border: 'border-indigo-500/30', glow: 'tier-platinum' },
}

const TIER_PERKS: Record<LoyaltyTier, string[]> = {
  Bronze: ['1 point = 1€ dépensé', 'Accès aux ventes privées', 'Newsletter exclusive'],
  Argent: ['Tout Bronze +', 'Livraison prioritaire', '10% de remise permanente', 'Retours gratuits'],
  Or: ['Tout Argent +', '15% de remise permanente', 'Accès early access collections', 'Service client dédié'],
  Platine: ['Tout Or +', '25% de remise permanente', 'Personal shopper', 'Invitations événements VIP', 'Livraison express offerte'],
}

const REWARDS = [
  { id: 'r1', name: 'Réduction 10€', points: 200, icon: '🏷️', expires: '31 Jan 2025' },
  { id: 'r2', name: 'Réduction 25€', points: 500, icon: '💰', expires: '28 Fév 2025' },
  { id: 'r3', name: 'Livraison Express Offerte', points: 150, icon: '🚀', expires: '30 Jan 2025' },
  { id: 'r4', name: 'Accessoire Offert', points: 750, icon: '🎁', expires: '31 Mar 2025' },
  { id: 'r5', name: 'Réduction 50€', points: 1000, icon: '⭐', expires: '30 Avr 2025' },
  { id: 'r6', name: 'Pièce Capsule -50%', points: 1500, icon: '👑', expires: '31 Mai 2025' },
]

const HISTORY = [
  { date: '5 Déc. 2024', action: 'Commande #KV-20241205', pts: '+399', positive: true },
  { date: '1 Déc. 2024', action: 'Commande #KV-20241201', pts: '+258', positive: true },
  { date: '18 Nov. 2024', action: 'Commande #KV-20241118', pts: '+189', positive: true },
  { date: '10 Nov. 2024', action: 'Parrainage ami', pts: '+100', positive: true },
  { date: '5 Nov. 2024', action: 'Réduction 10€ utilisée', pts: '-200', positive: false },
]

const TIERS_ORDER: LoyaltyTier[] = ['Bronze', 'Argent', 'Or', 'Platine']

export default function LoyaltyPage() {
  const { points, tier } = useUserStore()
  const [tab, setTab] = useState<'rewards' | 'history' | 'perks'>('rewards')
  const nextTier = getNextTier(tier)
  const progress = getTierProgress(points, tier)
  const colors = TIER_COLORS[tier]
  const nextThreshold = getNextTierThreshold(tier)

  return (
    <div>
      <Header title="Programme Fidélité" showBack backHref="/" />

      <div className="page-scroll">
        {/* Tier Card */}
        <div className={`mx-4 mt-2 rounded-3xl p-5 bg-gradient-to-br ${colors.bg} border ${colors.border} ${colors.glow} overflow-hidden relative`}>
          {/* Background decoration */}
          <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full opacity-10"
            style={{ background: colors.text }} />
          <div className="absolute -bottom-4 -left-4 w-20 h-20 rounded-full opacity-5"
            style={{ background: colors.text }} />

          <div className="relative z-10">
            {/* Tier badge */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="font-body text-xs uppercase tracking-[0.2em] mb-0.5"
                  style={{ color: colors.text }}>Niveau</p>
                <p className="font-display text-3xl font-semibold text-offwhite">{tier}</p>
              </div>
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: `${colors.text}20` }}>
                <svg width="28" height="28" viewBox="0 0 24 24"
                  fill={colors.text} stroke={colors.text} strokeWidth="0.5">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                </svg>
              </div>
            </div>

            {/* Points balance */}
            <p className="font-body text-xs text-muted mb-1">Solde de points</p>
            <p className="font-display text-4xl font-light text-offwhite mb-4">
              {points.toLocaleString('fr-FR')} <span className="text-xl" style={{ color: colors.text }}>pts</span>
            </p>

            {/* Progress bar */}
            {nextTier && (
              <div>
                <div className="flex justify-between font-body text-xs mb-1.5">
                  <span className="text-muted">{tier}</span>
                  <span style={{ color: colors.text }}>{nextTier}</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${progress}%`, backgroundColor: colors.text }} />
                </div>
                <p className="font-body text-xs text-muted mt-1.5">
                  Plus que <strong style={{ color: colors.text }}>{(nextThreshold - points).toLocaleString('fr-FR')} pts</strong> pour atteindre {nextTier}
                </p>
              </div>
            )}
            {!nextTier && (
              <p className="font-body text-sm font-medium" style={{ color: colors.text }}>
                🏆 Niveau maximum atteint
              </p>
            )}
          </div>
        </div>

        {/* Tiers overview */}
        <div className="mx-4 mt-4 grid grid-cols-4 gap-1.5">
          {TIERS_ORDER.map(t => {
            const c = TIER_COLORS[t]
            const isActive = t === tier
            const isPast = TIERS_ORDER.indexOf(t) < TIERS_ORDER.indexOf(tier)
            return (
              <div key={t}
                className={`flex flex-col items-center p-2 rounded-xl border text-center
                  ${isActive ? `border-opacity-60 border ${c.border}` : 'border-border'}`}
                style={isActive ? { borderColor: c.text + '60', backgroundColor: c.text + '08' } : {}}>
                <span className="text-xs mb-0.5" style={{ color: isPast || isActive ? c.text : '#444' }}>
                  {isPast || isActive ? '✓' : '○'}
                </span>
                <p className="font-body text-[10px] font-medium"
                  style={{ color: isPast || isActive ? c.text : '#666' }}>{t}</p>
                <p className="font-body text-[9px] text-muted">{TIER_THRESHOLDS[t]}pts</p>
              </div>
            )
          })}
        </div>

        {/* Tabs */}
        <div className="flex mx-4 mt-5 border border-border rounded-xl overflow-hidden">
          {(['rewards', 'perks', 'history'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-2.5 font-body text-xs font-medium transition-all
                ${tab === t ? 'bg-gold text-bg' : 'text-muted'}`}>
              {t === 'rewards' ? 'Récompenses' : t === 'perks' ? 'Avantages' : 'Historique'}
            </button>
          ))}
        </div>

        {/* Rewards */}
        {tab === 'rewards' && (
          <div className="px-4 mt-4 grid grid-cols-2 gap-3 mb-4">
            {REWARDS.map(r => {
              const canRedeem = points >= r.points
              return (
                <div key={r.id}
                  className={`p-4 rounded-2xl border flex flex-col items-center text-center gap-2
                    ${canRedeem ? 'border-gold/20 bg-gold/5' : 'border-border bg-s2 opacity-60'}`}>
                  <span className="text-2xl">{r.icon}</span>
                  <p className="font-body text-xs font-medium text-offwhite">{r.name}</p>
                  <p className="font-body text-xs text-gold">{r.points} pts</p>
                  <p className="font-body text-[10px] text-muted">Exp: {r.expires}</p>
                  <button
                    disabled={!canRedeem}
                    className={`w-full py-2 rounded-lg font-body text-xs font-semibold press-effect
                      ${canRedeem ? 'bg-gold text-bg' : 'bg-s3 text-muted cursor-not-allowed'}`}>
                    {canRedeem ? 'Utiliser' : `Manque ${r.points - points} pts`}
                  </button>
                </div>
              )
            })}
          </div>
        )}

        {/* Perks */}
        {tab === 'perks' && (
          <div className="px-4 mt-4 mb-4 space-y-3">
            {TIERS_ORDER.map(t => {
              const c = TIER_COLORS[t]
              const isActive = t === tier
              const isPast = TIERS_ORDER.indexOf(t) < TIERS_ORDER.indexOf(tier)
              return (
                <div key={t}
                  className={`p-4 rounded-2xl border ${isActive ? '' : 'opacity-50'}`}
                  style={isActive ? { borderColor: c.text + '40', backgroundColor: c.text + '08' } : { borderColor: '#2A2A2A' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-display text-lg font-semibold" style={{ color: c.text }}>{t}</span>
                    {(isActive || isPast) && <span className="font-body text-[10px] text-bg px-2 py-0.5 rounded-full" style={{ backgroundColor: c.text }}>✓ Actif</span>}
                  </div>
                  <ul className="space-y-1">
                    {TIER_PERKS[t].map(perk => (
                      <li key={perk} className="font-body text-xs text-muted flex items-center gap-2">
                        <span className="w-1 h-1 rounded-full flex-shrink-0" style={{ backgroundColor: c.text }} />
                        {perk}
                      </li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        )}

        {/* History */}
        {tab === 'history' && (
          <div className="px-4 mt-4 mb-4">
            {HISTORY.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-border">
                <div>
                  <p className="font-body text-sm text-offwhite">{h.action}</p>
                  <p className="font-body text-xs text-muted">{h.date}</p>
                </div>
                <span className={`font-body text-sm font-semibold ${h.positive ? 'text-gold' : 'text-danger'}`}>
                  {h.pts} pts
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
