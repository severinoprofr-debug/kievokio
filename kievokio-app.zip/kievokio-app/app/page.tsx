'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Header from './components/Header'
import BottomNav from './components/BottomNav'
import ProductCard from './components/ProductCard'
import { getFeatured, getNew, getSale } from './data/products'
import { useUserStore } from './store/user'

const HERO_SLIDES = [
  {
    title: 'BE OUTSIDE\nTHE BOX',
    sub: 'Collection Capsule Hiver 2025',
    cta: 'Découvrir',
    href: '/shop',
    bg: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&auto=format&fit=crop&q=80',
    accent: '#BFA46E',
  },
  {
    title: 'LA MODE\nQUI OSE TOUT',
    sub: 'Nouvelles Arrivées — Vestes & Manteaux',
    cta: 'Shop Now',
    href: '/shop?cat=vestes',
    bg: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&auto=format&fit=crop&q=80',
    accent: '#D4BC89',
  },
  {
    title: 'SOLDES\nJUSQU\'À -40%',
    sub: 'Pièces sélectionnées — Offre limitée',
    cta: 'En profiter',
    href: '/shop?cat=sale',
    bg: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=800&auto=format&fit=crop&q=80',
    accent: '#E05252',
  },
]

export default function HomePage() {
  const [slideIndex, setSlideIndex] = useState(0)
  const [mounted, setMounted] = useState(false)
  const featured = getFeatured()
  const newItems = getNew()
  const saleItems = getSale()
  const { tier, points } = useUserStore()

  useEffect(() => {
    setMounted(true)
    const interval = setInterval(() => {
      setSlideIndex(i => (i + 1) % HERO_SLIDES.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const slide = HERO_SLIDES[slideIndex]

  return (
    <div className="page-enter">
      <Header showBrand rightAction={undefined} />

      <div className="page-scroll">
        {/* ─── HERO SLIDER ─── */}
        <div className="relative h-[70dvh] overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center transition-all duration-700"
            style={{ backgroundImage: `url(${slide.bg})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-transparent" />

          {/* Slide content */}
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <p className="font-body text-xs tracking-[0.2em] text-gold mb-3 uppercase">
              {slide.sub}
            </p>
            <h1 className="font-display text-5xl font-light tracking-tight text-offwhite leading-none mb-5 whitespace-pre-line">
              {slide.title}
            </h1>
            <Link href={slide.href}
              className="inline-flex items-center gap-2 bg-gold text-bg font-body font-semibold text-sm px-6 py-3 rounded-full press-effect">
              {slide.cta}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </Link>
          </div>

          {/* Dots */}
          <div className="absolute bottom-6 right-6 flex gap-1.5">
            {HERO_SLIDES.map((_, i) => (
              <button key={i} onClick={() => setSlideIndex(i)}
                className={`rounded-full transition-all press-effect ${i === slideIndex ? 'w-4 h-1.5 bg-gold' : 'w-1.5 h-1.5 bg-offwhite/40'}`} />
            ))}
          </div>
        </div>

        {/* ─── LOYALTY TEASER ─── */}
        {mounted && (
          <Link href="/loyalty"
            className="mx-4 mt-4 flex items-center gap-3 p-4 rounded-2xl border border-gold/20 bg-s2 press-effect overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-r from-gold/5 to-transparent" />
            <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center flex-shrink-0 z-10">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#BFA46E" strokeWidth="1.8" strokeLinecap="round">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            </div>
            <div className="flex-1 z-10">
              <p className="font-body text-xs text-muted">Programme Fidélité · Niveau {tier}</p>
              <p className="font-display text-base font-semibold text-offwhite">
                {points.toLocaleString('fr-FR')} points
              </p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#BFA46E" strokeWidth="2" className="z-10">
              <path d="M9 18l6-6-6-6" />
            </svg>
          </Link>
        )}

        {/* ─── CATEGORIES ─── */}
        <div className="mt-6 px-4">
          <h2 className="font-display text-2xl text-offwhite mb-3">Catégories</h2>
          <div className="scroll-x flex gap-3 pb-1">
            {[
              { name: 'Robes', slug: 'robes', emoji: '👗' },
              { name: 'Vestes', slug: 'vestes', emoji: '🧥' },
              { name: 'Pantalons', slug: 'pantalons', emoji: '👖' },
              { name: 'Tops', slug: 'tops', emoji: '👚' },
              { name: 'Accessoires', slug: 'accessoires', emoji: '👜' },
            ].map(cat => (
              <Link key={cat.slug} href={`/shop?cat=${cat.slug}`}
                className="flex-shrink-0 flex flex-col items-center gap-1.5 press-effect">
                <div className="w-16 h-16 rounded-2xl bg-s2 border border-border flex items-center justify-center text-2xl">
                  {cat.emoji}
                </div>
                <span className="font-body text-[11px] text-muted">{cat.name}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* ─── NEW ARRIVALS ─── */}
        <div className="mt-7 px-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-2xl text-offwhite">Nouveautés</h2>
            <Link href="/shop?cat=new" className="font-body text-xs text-gold">Voir tout</Link>
          </div>
          <div className="scroll-x flex gap-3 pb-1">
            {newItems.map(p => (
              <div key={p.id} className="flex-shrink-0 w-[160px]">
                <ProductCard product={p} size="md" />
              </div>
            ))}
          </div>
        </div>

        {/* ─── EDITORIAL BANNER ─── */}
        <Link href="/shop" className="mx-4 mt-6 block relative rounded-2xl overflow-hidden h-[200px] press-effect">
          <img
            src="https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=800&auto=format&fit=crop&q=80"
            alt="Collection"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-bg/80 to-transparent flex flex-col justify-center p-5">
            <p className="font-body text-xs text-gold tracking-[0.2em] uppercase mb-1">Bestseller</p>
            <p className="font-display text-3xl text-offwhite font-light leading-tight">Robe<br/>Bandage</p>
            <p className="font-body text-xs text-muted mt-2">À partir de 175€</p>
          </div>
        </Link>

        {/* ─── FEATURED ─── */}
        <div className="mt-7 px-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-2xl text-offwhite">Coup de Cœur</h2>
            <Link href="/shop" className="font-body text-xs text-gold">Voir tout</Link>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {featured.slice(0, 4).map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>

        {/* ─── PROMO CODES ─── */}
        <div className="mx-4 mt-6 p-4 rounded-2xl bg-gradient-to-br from-gold/10 to-gold/5 border border-gold/15">
          <p className="font-body text-[10px] tracking-[0.2em] uppercase text-gold mb-1">Offre exclusive</p>
          <p className="font-display text-xl text-offwhite mb-1">-15% sur votre 1ère commande</p>
          <p className="font-body text-xs text-muted mb-3">Utilisez le code ci-dessous à la caisse</p>
          <div className="inline-flex items-center gap-2 bg-gold/10 border border-gold/30 rounded-lg px-3 py-2">
            <span className="font-body text-sm font-semibold text-gold tracking-widest">WELCOME15</span>
          </div>
        </div>

        {/* ─── SOLDES ─── */}
        <div className="mt-7 px-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-2xl text-offwhite">Soldes</h2>
            <Link href="/shop?cat=sale" className="font-body text-xs text-danger">Voir tout</Link>
          </div>
          <div className="scroll-x flex gap-3 pb-1">
            {saleItems.map(p => (
              <div key={p.id} className="flex-shrink-0 w-[160px]">
                <ProductCard product={p} size="md" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
