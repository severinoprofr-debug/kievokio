'use client'

import { useState } from 'react'
import Link from 'next/link'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import { useCartStore } from '../store/cart'

export default function CartPage() {
  const {
    items, removeItem, updateQuantity,
    subtotal, discount, total, promoCode, promoDiscount,
    applyPromo, loyaltyPointsEarned,
  } = useCartStore()

  const [promoInput, setPromoInput] = useState('')
  const [promoError, setPromoError] = useState(false)
  const [promoSuccess, setPromoSuccess] = useState(false)
  const [mounted, setMounted] = useState(false)

  // Needed to avoid hydration mismatch with persisted store
  if (typeof window !== 'undefined' && !mounted) {
    setTimeout(() => setMounted(true), 0)
  }

  const sub = subtotal()
  const disc = discount()
  const tot = total()
  const shipping = sub > 100 ? 0 : 6.9
  const points = loyaltyPointsEarned()

  const handlePromo = () => {
    const ok = applyPromo(promoInput)
    if (ok) { setPromoSuccess(true); setPromoError(false) }
    else { setPromoError(true); setPromoSuccess(false) }
  }

  if (!items.length) {
    return (
      <div>
        <Header title="Mon Panier" showBack backHref="/" />
        <div className="page-scroll flex flex-col items-center justify-center text-center px-8">
          <span className="text-6xl mb-4">🛒</span>
          <h2 className="font-display text-2xl text-offwhite mb-2">Panier vide</h2>
          <p className="font-body text-sm text-muted mb-6">Découvrez nos dernières collections et craquez pour votre prochaine pièce.</p>
          <Link href="/shop"
            className="bg-gold text-bg font-body font-semibold px-8 py-3 rounded-full press-effect text-sm">
            Découvrir la boutique
          </Link>
        </div>
        <BottomNav />
      </div>
    )
  }

  return (
    <div>
      <Header title={`Mon Panier (${items.reduce((s, i) => s + i.quantity, 0)})`} showBack backHref="/" />

      <div className="page-scroll">
        {/* Items */}
        <div className="px-4 space-y-3 mb-4">
          {items.map(item => (
            <div key={`${item.product.id}-${item.size}-${item.color}`}
              className="flex gap-3 p-3 rounded-2xl bg-s2 border border-border">
              {/* Image */}
              <Link href={`/product/${item.product.id}`} className="flex-shrink-0">
                <div className="w-20 h-24 rounded-xl overflow-hidden bg-s3">
                  <img src={item.product.image} alt={item.product.name}
                    className="w-full h-full object-cover" />
                </div>
              </Link>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-body text-[10px] text-muted uppercase tracking-wider">{item.product.category}</p>
                    <p className="font-body text-sm text-offwhite font-medium leading-snug line-clamp-2">{item.product.name}</p>
                  </div>
                  <button onClick={() => removeItem(item.product.id, item.size)}
                    className="text-muted press-effect p-1 flex-shrink-0">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M18 6L6 18M6 6l12 12" />
                    </svg>
                  </button>
                </div>

                {/* Variant tags */}
                <div className="flex gap-1.5 mt-1.5">
                  <span className="font-body text-[10px] text-muted border border-border px-2 py-0.5 rounded">
                    {item.size}
                  </span>
                  <span className="font-body text-[10px] text-muted border border-border px-2 py-0.5 rounded flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: item.colorHex }} />
                    {item.color}
                  </span>
                </div>

                {/* Qty + price */}
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-2 border border-border rounded-lg overflow-hidden">
                    <button onClick={() => updateQuantity(item.product.id, item.size, item.quantity - 1)}
                      className="w-7 h-7 flex items-center justify-center text-offwhite text-lg press-effect">−</button>
                    <span className="font-body text-sm text-offwhite w-5 text-center">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.product.id, item.size, item.quantity + 1)}
                      className="w-7 h-7 flex items-center justify-center text-offwhite text-lg press-effect">+</button>
                  </div>
                  <span className="font-body text-sm font-semibold text-gold">
                    {(item.product.price * item.quantity).toFixed(2)}€
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Promo code */}
        <div className="mx-4 mb-4">
          {promoCode ? (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-gold/5 border border-gold/20">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#BFA46E" strokeWidth="2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
              <span className="font-body text-xs text-gold flex-1">Code <strong>{promoCode}</strong> appliqué · -{promoDiscount}%</span>
            </div>
          ) : (
            <div className="flex gap-2">
              <input
                className="input-dark flex-1 text-sm"
                placeholder="Code promo"
                value={promoInput}
                onChange={e => setPromoInput(e.target.value.toUpperCase())}
                onKeyDown={e => e.key === 'Enter' && handlePromo()}
              />
              <button onClick={handlePromo}
                className="bg-s2 border border-border text-offwhite font-body text-sm px-4 rounded-lg press-effect">
                Appliquer
              </button>
            </div>
          )}
          {promoError && <p className="font-body text-xs text-danger mt-1.5">Code invalide. Essayez WELCOME15</p>}
        </div>

        {/* Loyalty points preview */}
        <div className="mx-4 mb-4 flex items-center gap-2 p-3 rounded-xl bg-gold/5 border border-gold/10">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#BFA46E" strokeWidth="1.8">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
          <p className="font-body text-xs text-muted flex-1">
            Vous allez gagner <strong className="text-gold">+{points} points</strong> avec cette commande
          </p>
        </div>

        {/* Order summary */}
        <div className="mx-4 p-4 rounded-2xl bg-s2 border border-border mb-4">
          <h3 className="font-body text-sm font-medium text-offwhite mb-3">Récapitulatif</h3>
          <div className="space-y-2">
            <div className="flex justify-between font-body text-sm">
              <span className="text-muted">Sous-total</span>
              <span className="text-offwhite">{sub.toFixed(2)}€</span>
            </div>
            {disc > 0 && (
              <div className="flex justify-between font-body text-sm">
                <span className="text-gold">Réduction ({promoDiscount}%)</span>
                <span className="text-gold">-{disc.toFixed(2)}€</span>
              </div>
            )}
            <div className="flex justify-between font-body text-sm">
              <span className="text-muted">Livraison</span>
              <span className={shipping === 0 ? 'text-green-400' : 'text-offwhite'}>
                {shipping === 0 ? 'Gratuite' : `${shipping.toFixed(2)}€`}
              </span>
            </div>
            {sub < 100 && shipping > 0 && (
              <p className="font-body text-[10px] text-muted">
                Plus que {(100 - sub).toFixed(2)}€ pour la livraison gratuite
              </p>
            )}
            <div className="h-px bg-border my-1" />
            <div className="flex justify-between font-body font-semibold">
              <span className="text-offwhite">Total</span>
              <span className="text-gold text-lg">{tot.toFixed(2)}€</span>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="px-4 mb-2">
          <button className="w-full py-4 bg-gold text-bg rounded-2xl font-body font-bold text-sm press-effect">
            Commander — {tot.toFixed(2)}€
          </button>
        </div>

        {/* Payment methods */}
        <div className="flex items-center justify-center gap-3 px-4 mb-2">
          {['Visa', 'MC', 'Apple Pay', 'Paypal'].map(pm => (
            <span key={pm} className="font-body text-[10px] text-muted border border-border/50 rounded px-2 py-1">{pm}</span>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
