'use client'

import { useState } from 'react'
import Link from 'next/link'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import ProductCard from '../components/ProductCard'
import { useUserStore } from '../store/user'
import { getById } from '../data/products'

const STATUS_COLORS: Record<string, string> = {
  'En cours': 'text-yellow-400 bg-yellow-400/10',
  Expédié: 'text-blue-400 bg-blue-400/10',
  Livré: 'text-green-400 bg-green-400/10',
  Annulé: 'text-danger bg-danger/10',
}

export default function ProfilePage() {
  const { isLoggedIn, name, email, tier, points, orders, wishlist, login, logout } = useUserStore()
  const [tab, setTab] = useState<'orders' | 'wishlist' | 'settings'>('orders')
  const [loginEmail, setLoginEmail] = useState('')
  const [loginName, setLoginName] = useState('')
  const [showLogin, setShowLogin] = useState(false)

  const wishedProducts = wishlist.map(id => getById(id)).filter(Boolean) as ReturnType<typeof getById>[]

  const handleLogin = () => {
    if (loginEmail && loginName) {
      login(loginEmail, loginName)
      setShowLogin(false)
    }
  }

  return (
    <div>
      <Header title="Mon Profil" showBack backHref="/" />

      <div className="page-scroll">
        {/* Profile header */}
        <div className="mx-4 mt-2 p-5 rounded-3xl bg-s2 border border-border">
          <div className="flex items-center gap-4">
            {/* Avatar */}
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-gold/30 to-gold/10 border border-gold/20 flex items-center justify-center flex-shrink-0">
              {isLoggedIn ? (
                <span className="font-display text-2xl text-gold font-semibold">
                  {name.charAt(0).toUpperCase()}
                </span>
              ) : (
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#BFA46E" strokeWidth="1.5">
                  <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              {isLoggedIn ? (
                <>
                  <p className="font-display text-xl text-offwhite font-medium">{name}</p>
                  <p className="font-body text-xs text-muted">{email}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="font-body text-[10px] px-2 py-0.5 rounded-full bg-gold/15 text-gold border border-gold/20">
                      {tier}
                    </span>
                    <span className="font-body text-[10px] text-muted">{points.toLocaleString('fr-FR')} pts</span>
                  </div>
                </>
              ) : (
                <>
                  <p className="font-display text-lg text-offwhite">Bienvenue</p>
                  <p className="font-body text-xs text-muted mb-2">Connectez-vous pour accéder à votre compte</p>
                  <button onClick={() => setShowLogin(true)}
                    className="bg-gold text-bg font-body text-xs font-semibold px-4 py-1.5 rounded-full press-effect">
                    Se connecter
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Quick stats */}
          {isLoggedIn && (
            <div className="grid grid-cols-3 gap-2 mt-4">
              {[
                { label: 'Commandes', value: orders.length },
                { label: 'Favoris', value: wishlist.length },
                { label: 'Points', value: points.toLocaleString('fr-FR') },
              ].map(stat => (
                <div key={stat.label} className="text-center p-2 rounded-xl bg-s3">
                  <p className="font-display text-lg text-gold">{stat.value}</p>
                  <p className="font-body text-[10px] text-muted">{stat.label}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Login modal */}
        {showLogin && !isLoggedIn && (
          <div className="fixed inset-0 bg-bg/90 backdrop-blur-sm z-50 flex items-end">
            <div className="w-full max-w-[430px] mx-auto bg-s2 rounded-t-3xl border-t border-border p-6 pb-10">
              <div className="w-10 h-1 rounded-full bg-border mx-auto mb-5" />
              <h2 className="font-display text-2xl text-offwhite mb-1">Se connecter</h2>
              <p className="font-body text-xs text-muted mb-5">Accédez à vos commandes, points et favoris</p>

              <div className="space-y-3 mb-4">
                <input className="input-dark w-full" placeholder="Prénom Nom"
                  value={loginName} onChange={e => setLoginName(e.target.value)} />
                <input className="input-dark w-full" type="email" placeholder="Email"
                  value={loginEmail} onChange={e => setLoginEmail(e.target.value)} />
              </div>

              <button onClick={handleLogin}
                className="w-full bg-gold text-bg font-body font-semibold py-4 rounded-2xl press-effect mb-3 text-sm">
                Continuer
              </button>

              <div className="divider-text mb-3">ou continuer avec</div>

              <div className="grid grid-cols-2 gap-2 mb-4">
                {['Apple', 'Google'].map(provider => (
                  <button key={provider} onClick={() => { login(`${provider.toLowerCase()}@demo.com`, provider + ' User'); setShowLogin(false) }}
                    className="flex items-center justify-center gap-2 border border-border rounded-xl py-3 font-body text-sm text-offwhite press-effect">
                    {provider === 'Apple' ? '🍎' : '🔵'} {provider}
                  </button>
                ))}
              </div>

              <button onClick={() => setShowLogin(false)}
                className="w-full text-center font-body text-xs text-muted press-effect">
                Annuler
              </button>
            </div>
          </div>
        )}

        {/* Tabs */}
        {isLoggedIn && (
          <>
            <div className="flex mx-4 mt-4 border border-border rounded-xl overflow-hidden">
              {(['orders', 'wishlist', 'settings'] as const).map(t => (
                <button key={t} onClick={() => setTab(t)}
                  className={`flex-1 py-2.5 font-body text-xs font-medium transition-all
                    ${tab === t ? 'bg-gold text-bg' : 'text-muted'}`}>
                  {t === 'orders' ? 'Commandes' : t === 'wishlist' ? 'Favoris' : 'Paramètres'}
                </button>
              ))}
            </div>

            {/* Orders */}
            {tab === 'orders' && (
              <div className="px-4 mt-4 space-y-3 mb-4">
                {orders.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-3xl mb-2">📦</p>
                    <p className="font-body text-sm text-muted">Aucune commande pour l&apos;instant</p>
                  </div>
                ) : orders.map(order => (
                  <div key={order.id} className="p-4 rounded-2xl bg-s2 border border-border">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-body text-sm font-medium text-offwhite">{order.id}</p>
                        <p className="font-body text-xs text-muted">{order.date} · {order.items} article{order.items > 1 ? 's' : ''}</p>
                      </div>
                      <span className={`font-body text-[10px] font-semibold px-2.5 py-1 rounded-full ${STATUS_COLORS[order.status]}`}>
                        {order.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-body text-sm font-semibold text-gold">{order.total}€</span>
                      {order.pointsEarned > 0 && (
                        <span className="font-body text-[10px] text-gold/70">+{order.pointsEarned} pts</span>
                      )}
                    </div>
                    {order.status === 'Expédié' && (
                      <button className="w-full mt-2 py-2 border border-gold/20 rounded-lg font-body text-xs text-gold press-effect">
                        Suivre la livraison
                      </button>
                    )}
                    {order.status === 'Livré' && (
                      <button className="w-full mt-2 py-2 border border-border rounded-lg font-body text-xs text-muted press-effect">
                        Laisser un avis
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Wishlist */}
            {tab === 'wishlist' && (
              <div className="px-4 mt-4 mb-4">
                {wishedProducts.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-3xl mb-2">🤍</p>
                    <p className="font-body text-sm text-muted">Votre liste de souhaits est vide</p>
                    <Link href="/shop" className="font-body text-xs text-gold mt-2 inline-block">
                      Explorer la boutique →
                    </Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    {wishedProducts.map(p => p && <ProductCard key={p.id} product={p} />)}
                  </div>
                )}
              </div>
            )}

            {/* Settings */}
            {tab === 'settings' && (
              <div className="px-4 mt-4 mb-4 space-y-2">
                {[
                  { icon: '👤', label: 'Informations personnelles', sub: name },
                  { icon: '📍', label: 'Adresses de livraison', sub: '1 adresse enregistrée' },
                  { icon: '💳', label: 'Moyens de paiement', sub: '•••• 4242' },
                  { icon: '🔔', label: 'Notifications', sub: 'Activées' },
                  { icon: '🌐', label: 'Langue', sub: 'Français' },
                  { icon: '🔒', label: 'Confidentialité & Données', sub: '' },
                  { icon: '❓', label: 'Aide & FAQ', sub: '' },
                ].map(item => (
                  <button key={item.label}
                    className="w-full flex items-center gap-3 p-4 rounded-xl bg-s2 border border-border press-effect text-left">
                    <span className="text-xl flex-shrink-0">{item.icon}</span>
                    <div className="flex-1">
                      <p className="font-body text-sm text-offwhite">{item.label}</p>
                      {item.sub && <p className="font-body text-xs text-muted">{item.sub}</p>}
                    </div>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="2">
                      <path d="M9 18l6-6-6-6" />
                    </svg>
                  </button>
                ))}

                <button onClick={logout}
                  className="w-full flex items-center gap-3 p-4 rounded-xl bg-danger/5 border border-danger/20 press-effect mt-4">
                  <span className="text-xl">🚪</span>
                  <p className="font-body text-sm text-danger flex-1 text-left">Se déconnecter</p>
                </button>
              </div>
            )}
          </>
        )}

        {/* Guest CTA */}
        {!isLoggedIn && (
          <div className="mx-4 mt-4 space-y-3">
            <div className="p-4 rounded-2xl bg-s2 border border-border">
              <p className="font-body text-xs text-muted mb-2">🎁 Rejoindre le programme fidélité</p>
              <p className="font-display text-lg text-offwhite mb-3">Gagnez des points à chaque achat</p>
              <button onClick={() => setShowLogin(true)}
                className="w-full bg-gold text-bg font-body font-semibold py-3 rounded-xl press-effect text-sm">
                Créer un compte gratuit
              </button>
            </div>
            <Link href="/shop"
              className="flex items-center justify-between p-4 rounded-2xl bg-s2 border border-border press-effect">
              <span className="font-body text-sm text-offwhite">Continuer sans compte</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="2">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </Link>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
